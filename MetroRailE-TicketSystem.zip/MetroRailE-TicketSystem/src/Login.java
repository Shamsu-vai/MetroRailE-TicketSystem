public class Login {
    private String userName;
    private String password;
    boolean hasAccess;

    Login(){

    }
}
